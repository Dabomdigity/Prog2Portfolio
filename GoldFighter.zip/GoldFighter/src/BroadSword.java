//
public class BroadSword extends Items {

	public BroadSword(int dmg, int id, int prc, boolean has) {
		super(dmg, id, prc, has);
		dmg = 18;
		id = 2;
		prc = 35;
		has = false;	}

}
