//
public class CheapSword extends Items {

	public CheapSword(int dmg, int id, int prc, boolean has) {
		super(dmg, id, prc, has);
		dmg = 10;
		id = 1;
		prc = 25;
		has = false;
	}

}
