//
public class CupOfMoltenChocolate extends Items {

	public CupOfMoltenChocolate(int dmg, int id, int prc, boolean has) {
		super(dmg, id, prc, has);
		dmg = 100;
		id = 5;
		prc = 100;
		has = false;	}

}
