//
public class Cutlass extends Items {

	public Cutlass(int dmg, int id, int prc, boolean has) {
		super(dmg, id, prc, has);
		dmg = 25;
		id = 3;
		prc = 50;
		has = false;	}

}
