import java.awt.Graphics;

public abstract class GameObject {
	
	protected int x, y;
	protected int valX, valY;
	
}
