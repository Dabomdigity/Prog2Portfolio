//
public class Gold {

	private int value;
	private int chance;
	
	public Gold(int val, int chnc) {
		value = val;
		chance = chnc;
	}
	
	public void setVal(int change) {
		value = change;
	}
	
	public int getVal() {
		return value;
	}
	
	public void setChance(int change) {
		chance = change;
	}
	
	public int getChance() {
		return  chance;
	}
}
