//
public class GoldChunk extends Gold {

	public GoldChunk(int val, int chnc) {
		super(val, chnc);
		val = 25;
		chnc = 40;
	}

}
