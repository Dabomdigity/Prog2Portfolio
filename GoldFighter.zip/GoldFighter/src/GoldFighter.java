
public class GoldFighter {

}
