//
public class GoldIngot extends Gold {

	public GoldIngot(int val, int chnc) {
		super(val, chnc);
		val = 50;
		chnc = 10;
	}

}
