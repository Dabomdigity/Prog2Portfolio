//
public class GoldNugget extends Gold {

	public GoldNugget(int val, int chnc) {
		super(val, chnc);
		val = 5;
		chnc = 75;
		}
}
