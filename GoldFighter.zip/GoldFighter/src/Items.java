//
public class Items {

	private int damage;
	private int identification;
	private int price;
	private boolean owns;
	
	public Items(int dmg, int id, int prc, boolean has) {
		
	damage = dmg;
	identification = id;
	price = prc;
	owns = has;
	
	}

	public void setDamage(int val) {
		damage = val;
	}
	
	public int getDamage() {
		return damage;
	}
	
	public void setID(int val) {
		identification = val;
	}
	
	public int getID() {
		return identification;
	}
	public void setPrice(int val) {
		price = val;
	}
	
	public int getPrice() {
		return price;
	}
	
	public void setOwn(boolean val) {
		owns = val;
	}
	
	public boolean getOwn() {
		return owns;
	}
}
