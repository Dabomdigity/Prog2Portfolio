//
public class Sabre extends Items {

	public Sabre(int dmg, int id, int prc, boolean has) {
		super(dmg, id, prc, has);
		dmg = 35;
		id = 4;
		prc = 65;
		has = false;
	}

}
