//
public class Stick extends Items {

	public Stick(int dmg, int id, int prc, boolean has) {
		super(dmg, id, prc, has);
		dmg = 3;
		id = 0;
		prc = 10;
		has = false;
	}

}
