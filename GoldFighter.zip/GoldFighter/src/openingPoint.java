//
public class openingPoint {

	public static void main(String[] args) {
		
		
	}
	
}
