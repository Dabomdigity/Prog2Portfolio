
public class winScreen extends Menus {

}
