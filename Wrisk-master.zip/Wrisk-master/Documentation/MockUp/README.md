1. ![Mockup of Title Screen](https://github.com/SkylineHigh/Wrisk/edit/master/MockUp/WriskTitke.pdf)
1. ![Mockup of World Map](https://github.com/SkylineHigh/Wrisk/blob/master/MockUp/Map.pdf)
