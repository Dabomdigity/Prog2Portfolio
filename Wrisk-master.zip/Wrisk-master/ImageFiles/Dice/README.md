These are the image files for the dice during gameplay.
