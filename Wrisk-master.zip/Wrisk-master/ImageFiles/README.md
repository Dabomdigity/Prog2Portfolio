# Image Files
These files are the images for use in the game Wrisk.


# Credits
* A huge thank you to Jack Smith for producing the clash.gif file.
* Dice made by Marko McDowell
* Cards made by Ed Carcano
* GUIs made by Christopher Mulcock
