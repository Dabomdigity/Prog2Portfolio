![Wrisk Logo](/ImageFiles/logoSmall.png)

Wrisk
=====
### Contributers w/ Assignments

Marko McDowell will do much of the class building and game mechanics as the lead developer, Christopher (Will) Mulcock is developing mostly graphics, the maps, and some class design, and Edwin Carcano is the developer of graphics design and other art. There will be large overlap between these tasks as the loss of much of the dev team has necessitated.  

### Features
The classic game of Risk, but with a twist. There are multiple different scenarios to play through and even a random world generator. It is a turn-based strategy game where you try to take over the world.

# Forseen Challenges
 Making the world map
 
 terrain generation

 displaying the dice when rolling
 
=====
### Update: 2/22/17
=====

We lost about half of our group in class due to the end of the semester, so some aspects of challenges have been altered or abandoned, due to work load versus the end of the school year.

Making the world map: This map will stay the same, aside from a change in graphics style since none of us have expreience drawing up graphics.

Terrain Generation: Unfortunately, our idea for a randomly-generated map has been scrapped until further notice. None of us have the time or knowledge of how to approach this at the time.

Displaying the dice when rolling: Stays the same. We have a good idea of how to do this.

### ===End===
