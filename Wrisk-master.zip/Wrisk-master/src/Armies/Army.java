package Armies;

public abstract class Army
{
	protected int StandardArmyNumber;
	abstract public void getArmyCount();
}
