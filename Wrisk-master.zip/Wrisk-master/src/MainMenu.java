import java.awt.Rectangle;

public class MainMenu
{
	// this class will draw the main menu
	
	public void display()
	{
		Rectangle rect = new Rectangle(300, 50, 200, 800);
	}
}
